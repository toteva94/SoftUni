﻿namespace _04.DistanceBetweenPoints
{
    using System;

   public class Point
    {
        public int X { get; set; }

        public int Y { get; set; }
    }
}
